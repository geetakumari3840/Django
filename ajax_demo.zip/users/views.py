from django.shortcuts import render
from django.http import JsonResponse
from .models import Person
import json

def home(request):
    return render(request, 'users/index.html')

def save_person(request):
    if request.method == "POST":
        data = json.loads(request.body)
        name = data.get("name")
        Person.objects.create(name=name)
        return JsonResponse({"message": f"{name} saved!"})
    return JsonResponse({"error": "Invalid request"}, status=400)
